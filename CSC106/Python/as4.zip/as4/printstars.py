
# this function prints num_stars stars followed
# by a newline character
def printStars(num_stars):
	for i in range(0,num_stars):
		print "*",
	print

def printSquare(width):
	print "printSquare not implemented yet"

def printTriangle(width):
	print "printTriangle not implemented yet"

def printTriangleRecursive(cur_width,width):	
	print "printTriangleRecursive not implemented yet"


def printFlippedTriangle(width):
	print "printFlippedTriangle not implemented yet"





