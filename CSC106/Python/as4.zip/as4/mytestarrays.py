from arrays import *

A = [1,2,3,4,5]
print(A)
print "Count even: "+str(countEven(A))
print "Sum Every 1: "+str(sumEveryN(A,1))
print "Sum Every 2: "+str(sumEveryN(A,2))

A = [2,3,4,5,6,8,9,10]
print(A)
print "Count even: "+str(countEven(A))
print "Sum Every 1: "+str(sumEveryN(A,1))
print "Sum Every 2: "+str(sumEveryN(A,2))

