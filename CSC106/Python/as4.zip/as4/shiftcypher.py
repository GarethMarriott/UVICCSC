
# This function will return a number between 0 and 25
# that corresponds to the position in the alphabet of
# the character.
def getNumForChar(char):
	return ord(char)-65

# This function will return a character that appears at
# position num in the alphabet.
def getCharForNum(num):
	return chr(num+65)


def encryptString(mystr,shift):
	newStr = "encrypt not implemented"
	return newStr

def decryptString(mystr,shift):
	newStr = "decrypt not implemented yet"
	return newStr





