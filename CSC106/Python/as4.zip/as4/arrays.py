
# should return the number of even numbers
# in the array A
def countEven(A):
	return 0

# should return the sum of every Nth number,
# starting with the elemenet at index 0
def sumEveryN(A, N):
	return 0