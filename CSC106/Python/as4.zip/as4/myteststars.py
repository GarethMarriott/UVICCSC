
from printstars import *

printSquare(5)
print
printTriangle(5)
printTriangleRecursive(1,5)
printFlippedTriangle(5)